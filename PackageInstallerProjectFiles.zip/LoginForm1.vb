Imports System.IO
Imports MySql.Data.MySqlClient

Public Class LoginForm1

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Dim myreader As MySqlDataReader


            strSQL = "Select * from admin where username = '" _
                & .UsernameTextBox.Text & "' and password = ('" _
                & .PasswordTextBox.Text & "')"
            'MsgBox(strSQL)
            mycmd.CommandText = strSQL
            mycmd.Connection = myconn

            myreader = mycmd.ExecuteReader
            If myreader.HasRows Then
                .Hide()
                MenuForm3.Show()
            Else
                MessageBox.Show("Invalid username or password")
            End If
            Call Disconnect_to_DB()
        End With
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Hide()
        RegisterForm1.Show()
    End Sub

    Private Sub btnmanual_Click(sender As Object, e As EventArgs) Handles btnmanual.Click
        Dim fileName As String = "usersmanual.pdf"
        Dim folderPath As String = Path.Combine(Environment.CurrentDirectory, "manual")
        Dim filePath As String = Path.Combine(folderPath, fileName)

        If File.Exists(filePath) Then
            Process.Start(filePath)
        Else
            MessageBox.Show("File does not exist")
        End If
    End Sub


End Class
